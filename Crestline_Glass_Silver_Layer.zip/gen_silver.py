#!/usr/bin/env python3
"""
Silver-layer synthetic data generator
Crestline Glass Corporation (fictional float-glass manufacturer)
Procure-to-produce scenario, 1 Jul 2026 – 30 Sep 2026.

Flow simulated event by event:
  monthly demand forecast -> float / finishing line schedule -> daily MRP
  -> purchase requisition -> approval -> purchase order -> supplier acknowledgement
  -> delivery schedule lines -> shipment (ASN) -> goods receipt -> quality inspection
  -> usage decision (release / deviation / block) -> NCR + return to vendor
  -> supplier invoice -> inventory issues to production (FIFO by batch)
  -> production order confirmation, internal cullet return, month-end stock count.
"""
import os, math, heapq, itertools, datetime as dt
from collections import defaultdict, deque
import numpy as np
import pandas as pd

SEED = 20261009
rng = np.random.default_rng(SEED)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "silver")
os.makedirs(OUT, exist_ok=True)

START, END = dt.date(2026, 7, 1), dt.date(2026, 9, 30)
PLAN_END = dt.date(2026, 11, 30)          # MRP looks beyond the data window
END_TS = dt.datetime(2026, 9, 30, 23, 59, 59)
OPEN_TS = dt.datetime(2026, 6, 30, 23, 59, 0)
COMPANY = "Crestline Glass Corporation"


def drange(a, b):
    return [a + dt.timedelta(i) for i in range((b - a).days + 1)]


SIM_DAYS = drange(START, END)
PLAN_DAYS = drange(START, PLAN_END)
HOLIDAYS = {dt.date(2026, 7, 3): "Independence Day (observed)", dt.date(2026, 9, 7): "Labor Day",
            dt.date(2026, 11, 26): "Thanksgiving Day", dt.date(2026, 12, 25): "Christmas Day"}


def at(d, h):
    """datetime at date d + h hours (h may exceed 24)."""
    return dt.datetime(d.year, d.month, d.day) + dt.timedelta(hours=float(h))


def r3(x):
    return round(float(x), 3)


# =====================================================================================
# MASTER DATA
# =====================================================================================
PLANTS = [
    dict(plant_id="PL01", plant_name="Marion Float Works", company_name=COMPANY, city="Marion", state="OH",
         country="US", region="Midwest", timezone="America/New_York", commissioned_year=1998,
         float_line_count=2, has_lamination=True, has_coater=True),
    dict(plant_id="PL02", plant_name="Temple Float Works", company_name=COMPANY, city="Temple", state="TX",
         country="US", region="South", timezone="America/Chicago", commissioned_year=2006,
         float_line_count=1, has_lamination=False, has_coater=True),
    dict(plant_id="PL03", plant_name="Fresno Float Works", company_name=COMPANY, city="Fresno", state="CA",
         country="US", region="West", timezone="America/Los_Angeles", commissioned_year=2011,
         float_line_count=1, has_lamination=True, has_coater=False),
]

LINES = [  # line_id, plant, type, name, nameplate tonnes/day, capacity basis
    ("FL-PL01-1", "PL01", "FLOAT", "Float Line 1", 650, "t pull/day"),
    ("FL-PL01-2", "PL01", "FLOAT", "Float Line 2", 550, "t pull/day"),
    ("LAM-PL01-1", "PL01", "LAMINATION", "Laminating Line 1", 160, "t good/day"),
    ("CTR-PL01-1", "PL01", "COATER", "MSVD Coater 1", 380, "t good/day"),
    ("FL-PL02-1", "PL02", "FLOAT", "Float Line 1", 700, "t pull/day"),
    ("CTR-PL02-1", "PL02", "COATER", "MSVD Coater 1", 360, "t good/day"),
    ("FL-PL03-1", "PL03", "FLOAT", "Float Line 1", 600, "t pull/day"),
    ("LAM-PL03-1", "PL03", "LAMINATION", "Laminating Line 1", 140, "t good/day"),
]
LINE = {l[0]: dict(line_id=l[0], plant_id=l[1], line_type=l[2], line_name=l[3], cap=l[4], basis=l[5]) for l in LINES}

PRODUCTS = [  # id, name, family, glass_type, thickness mm, route, kg/m2, std yield
    ("PRD-CLR04", "Clear Float Glass 4 mm", "FLOAT", "CLEAR", 4.0, "FLOAT", 10.0, 0.880),
    ("PRD-CLR06", "Clear Float Glass 6 mm", "FLOAT", "CLEAR", 6.0, "FLOAT", 15.0, 0.885),
    ("PRD-LIR06", "Low-Iron Ultra-Clear Float Glass 6 mm", "FLOAT", "LOW_IRON", 6.0, "FLOAT", 15.0, 0.860),
    ("PRD-GRY06", "Grey Tinted Float Glass 6 mm", "FLOAT", "TINTED", 6.0, "FLOAT", 15.0, 0.870),
    ("PRD-LAM838", "Laminated Safety Glass 8.38 mm (4 + 0.38 PVB + 4)", "LAMINATED", "CLEAR", 8.38,
     "LAMINATION", 20.4, 0.950),
    ("PRD-LOE06", "Low-E Coated Glass 6 mm (sputtered, single silver)", "COATED", "CLEAR", 6.0,
     "COATING", 15.0, 0.965),
]
PROD = {p[0]: dict(product_id=p[0], name=p[1], family=p[2], glass_type=p[3], thk=p[4], route=p[5],
                   kgm2=p[6], std_yield=p[7]) for p in PRODUCTS}

MATERIALS = [  # id, name, group, uom, storage type, std price USD/uom, shelf life days, hazardous
    ("RM-SAND-STD", "Silica Sand - Float Grade", "BATCH_MAJOR", "t", "SILO", 52.0, None, False),
    ("RM-SAND-LI", "Silica Sand - Low-Iron Grade", "BATCH_MAJOR", "t", "SILO", 96.0, None, False),
    ("RM-SODA", "Soda Ash - Dense (Na2CO3)", "BATCH_MAJOR", "t", "SILO", 295.0, None, False),
    ("RM-DOLO", "Dolomite - Glass Grade", "BATCH_MAJOR", "t", "SILO", 48.0, None, False),
    ("RM-LIME", "Limestone - Glass Grade", "BATCH_MAJOR", "t", "SILO", 38.0, None, False),
    ("RM-SALT", "Salt Cake (Sodium Sulfate)", "BATCH_MINOR", "t", "SILO", 185.0, None, False),
    ("RM-CARB", "Carbon - Anthracite Fines", "BATCH_MINOR", "t", "BIN", 330.0, None, False),
    ("RM-CULL", "Flat Glass Cullet - Flint", "CULLET", "t", "STOCKPILE", 68.0, None, False),
    ("RM-FEOX", "Iron Oxide (Rouge)", "COLORANT", "kg", "WAREHOUSE", 1.45, 730, False),
    ("RM-COOX", "Cobalt Oxide", "COLORANT", "kg", "WAREHOUSE", 38.0, 730, True),
    ("RM-SELN", "Selenium Powder", "COLORANT", "kg", "WAREHOUSE", 29.0, 730, True),
    ("RM-PVB", "PVB Interlayer 0.38 mm Clear", "INTERLAYER", "m2", "CLIMATE_WAREHOUSE", 3.85, 365, False),
    ("RM-TGT-AG", "Silver Rotary Sputtering Target", "COATING_TARGET", "kg", "WAREHOUSE", 1520.0, None, False),
    ("RM-TGT-ZNSN", "Zinc-Tin Rotary Sputtering Target", "COATING_TARGET", "kg", "WAREHOUSE", 88.0, None, False),
]
MAT = {m[0]: dict(material_id=m[0], name=m[1], group=m[2], uom=m[3], storage=m[4], price=m[5],
                  shelf=m[6], haz=m[7]) for m in MATERIALS}

# Melt recipes per tonne of glass PULLED (melted) on a float line
BASE = {"RM-SAND-STD": 0.580, "RM-SODA": 0.180, "RM-DOLO": 0.140, "RM-LIME": 0.045,
        "RM-SALT": 0.0080, "RM-CARB": 0.00040, "RM-CULL": 0.200}
RECIPE = {
    "PRD-CLR04": dict(BASE),
    "PRD-CLR06": dict(BASE),
    "PRD-LIR06": {"RM-SAND-LI": 0.590, "RM-SODA": 0.182, "RM-DOLO": 0.128, "RM-LIME": 0.052,
                  "RM-SALT": 0.0090, "RM-CULL": 0.120},
    "PRD-GRY06": dict(BASE, **{"RM-FEOX": 3.8, "RM-COOX": 0.080, "RM-SELN": 0.025}),
}
# Finishing BOMs per tonne of GOOD output
FINISH_BOM = {
    "PRD-LAM838": {"substrate": ("PRD-CLR04", 1.03), "RM-PVB": 50.5},
    "PRD-LOE06": {"substrate": ("PRD-CLR06", 1.04), "RM-TGT-AG": 0.024, "RM-TGT-ZNSN": 0.100},
}
ROLE = {"BATCH_MAJOR": "BATCH", "BATCH_MINOR": "BATCH", "CULLET": "CULLET", "COLORANT": "COLORANT",
        "INTERLAYER": "INTERLAYER", "COATING_TARGET": "COATING"}

# Campaign plans (product, days) per float line per month; Oct/Nov repeat September proportions
CAMPAIGN = {
    "FL-PL01-1": {7: [("PRD-CLR06", 31)], 8: [("PRD-CLR06", 31)], 9: [("PRD-CLR06", 30)]},
    "FL-PL01-2": {7: [("PRD-CLR04", 23), ("PRD-GRY06", 8)], 8: [("PRD-CLR04", 22), ("PRD-GRY06", 9)],
                  9: [("PRD-CLR04", 22), ("PRD-GRY06", 8)]},
    "FL-PL02-1": {7: [("PRD-CLR06", 22), ("PRD-CLR04", 9)], 8: [("PRD-CLR06", 21), ("PRD-CLR04", 10)],
                  9: [("PRD-CLR06", 21), ("PRD-CLR04", 9)]},
    "FL-PL03-1": {7: [("PRD-CLR04", 16), ("PRD-LIR06", 15)], 8: [("PRD-CLR04", 15), ("PRD-LIR06", 16)],
                  9: [("PRD-CLR04", 16), ("PRD-LIR06", 14)]},
}
FINISH_LINE_PRODUCT = {"LAM-PL01-1": "PRD-LAM838", "LAM-PL03-1": "PRD-LAM838",
                       "CTR-PL01-1": "PRD-LOE06", "CTR-PL02-1": "PRD-LOE06"}

# ---------------- Suppliers ----------------
# id, name, city, state, country, type, tier, p_late, ack_hours, p_push, quality_sd_mult, p_coa,
# terms, currency, since, esg
SUPPLIERS = [
    ("SUP001", "Ridgeway Silica Inc.", "Portage", "WI", "US", "MINE_PRODUCER", "STRATEGIC", .05, 8, .03, .85, .99, "NET45", "USD", 2009, "A"),
    ("SUP002", "Lakeshore Industrial Minerals LLC", "Muskegon", "MI", "US", "MINE_PRODUCER", "PREFERRED", .08, 14, .05, 1.0, .97, "NET45", "USD", 2014, "B"),
    ("SUP003", "Prairie Sand & Gravel Co.", "Brady", "TX", "US", "MINE_PRODUCER", "APPROVED", .12, 30, .10, 1.15, .86, "NET30", "USD", 2019, "C"),
    ("SUP004", "Sierra Pacific Silica", "Patterson", "CA", "US", "MINE_PRODUCER", "PREFERRED", .07, 12, .04, 1.0, .97, "NET45", "USD", 2012, "B"),
    ("SUP005", "Northstar High-Purity Minerals", "Emmett", "ID", "US", "MINE_PRODUCER", "STRATEGIC", .06, 10, .05, .80, .99, "NET60", "USD", 2015, "A"),
    ("SUP006", "Green River Alkali Corp.", "Green River", "WY", "US", "CHEMICAL_PRODUCER", "STRATEGIC", .04, 6, .02, .80, 1.0, "NET45", "USD", 2005, "A"),
    ("SUP007", "Western Trona Company", "Rock Springs", "WY", "US", "CHEMICAL_PRODUCER", "STRATEGIC", .07, 10, .04, .90, .99, "NET45", "USD", 2008, "B"),
    ("SUP008", "Bluestone Aggregates Inc.", "Maple Grove", "OH", "US", "MINE_PRODUCER", "PREFERRED", .05, 8, .03, .90, .98, "NET30", "USD", 2001, "B"),
    ("SUP009", "Lone Star Dolomite & Lime", "Lampasas", "TX", "US", "MINE_PRODUCER", "APPROVED", .09, 20, .06, 1.05, .95, "NET30", "USD", 2007, "C"),
    ("SUP010", "Cascade Mineral Products", "Fernley", "NV", "US", "MINE_PRODUCER", "APPROVED", .08, 16, .05, 1.0, .96, "NET30", "USD", 2012, "B"),
    ("SUP011", "Gulf Coast Sulfate Chemicals", "Pasadena", "TX", "US", "CHEMICAL_PRODUCER", "PREFERRED", .06, 12, .03, .95, .98, "NET30", "USD", 2010, "B"),
    ("SUP012", "Keystone Carbon Products", "Latrobe", "PA", "US", "PROCESSOR", "APPROVED", .10, 24, .05, 1.10, .94, "NET30", "USD", 2016, "C"),
    ("SUP013", "ReGlass Recovery Services", "Columbus", "OH", "US", "RECYCLER", "PREFERRED", .07, 6, .03, 1.0, .95, "NET30", "USD", 2013, "A"),
    ("SUP014", "Circular Glass Partners", "Houston", "TX", "US", "RECYCLER", "APPROVED", .09, 12, .04, 1.05, .93, "NET30", "USD", 2018, "B"),
    ("SUP015", "Pigmentec Specialty Oxides", "Easton", "PA", "US", "CHEMICAL_PRODUCER", "APPROVED", .06, 20, .05, .95, .97, "NET45", "USD", 2011, "B"),
    ("SUP016", "Meridian Fine Chemicals", "Tucson", "AZ", "US", "DISTRIBUTOR", "APPROVED", .08, 24, .06, 1.0, .95, "NET30", "USD", 2017, "C"),
    ("SUP017", "Interlayer Solutions Inc.", "Springfield", "MO", "US", "MANUFACTURER", "STRATEGIC", .05, 10, .03, .85, 1.0, "NET60", "USD", 2008, "A"),
    ("SUP018", "Polylam Interlayers GmbH", "Krefeld", "NW", "DE", "MANUFACTURER", "APPROVED", .06, 30, .25, 1.0, 1.0, "NET60", "EUR", 2020, "A"),
    ("SUP019", "Vacuum Coat Materials Inc.", "Loveland", "CO", "US", "MANUFACTURER", "STRATEGIC", .05, 12, .05, .85, 1.0, "NET45", "USD", 2010, "A"),
    ("SUP020", "Apex Sputtering Targets Co.", "Lowell", "MA", "US", "MANUFACTURER", "APPROVED", .10, 26, .10, 1.10, .97, "NET45", "USD", 2019, "B"),
    ("SUP021", "Golden State Cullet Co.", "Stockton", "CA", "US", "RECYCLER", "APPROVED", .08, 10, .04, 1.20, .93, "NET30", "USD", 2016, "C"),
]
SUP = {s[0]: dict(supplier_id=s[0], name=s[1], city=s[2], state=s[3], country=s[4], stype=s[5], tier=s[6],
                  p_late=s[7], ack_h=s[8], p_push=s[9], qsd=s[10], p_coa=s[11], terms=s[12], ccy=s[13],
                  since=s[14], esg=s[15]) for s in SUPPLIERS}
TERMS_DAYS = {"NET30": 30, "NET45": 45, "NET60": 60}

CARRIERS = [
    ("CAR01", "Midland Northern Railroad", "RAIL", "US"),
    ("CAR02", "Great Plains & Pacific Railway", "RAIL", "US"),
    ("CAR03", "Interstate Bulk Haulers", "TRUCK", "US"),
    ("CAR04", "Summit Pneumatic Tank Lines", "TRUCK", "US"),
    ("CAR05", "Lone Star Freightways", "TRUCK", "US"),
    ("CAR06", "Pacific Valley Transport", "TRUCK", "US"),
    ("CAR07", "BlueWave Ocean Lines", "OCEAN", "DK"),
    ("CAR08", "Keystone LTL Express", "TRUCK", "US"),
]
# (supplier, plant) -> transport mode, carrier, transit days, supplier processing days
LANES = {
    ("SUP001", "PL01"): ("RAIL", "CAR01", 3, 2), ("SUP001", "PL02"): ("RAIL", "CAR01", 5, 2),
    ("SUP001", "PL03"): ("RAIL", "CAR02", 7, 2), ("SUP002", "PL01"): ("RAIL", "CAR01", 2, 2),
    ("SUP003", "PL02"): ("TRUCK_BULK", "CAR05", 1, 1), ("SUP004", "PL03"): ("TRUCK_BULK", "CAR06", 1, 1),
    ("SUP005", "PL03"): ("RAIL", "CAR02", 3, 2),
    ("SUP006", "PL01"): ("RAIL", "CAR02", 7, 2), ("SUP006", "PL02"): ("RAIL", "CAR02", 5, 2),
    ("SUP006", "PL03"): ("RAIL", "CAR02", 4, 2),
    ("SUP007", "PL01"): ("RAIL", "CAR02", 7, 2), ("SUP007", "PL02"): ("RAIL", "CAR02", 5, 2),
    ("SUP007", "PL03"): ("RAIL", "CAR02", 4, 2),
    ("SUP008", "PL01"): ("TRUCK_BULK", "CAR03", 1, 1), ("SUP009", "PL02"): ("TRUCK_BULK", "CAR05", 1, 1),
    ("SUP010", "PL03"): ("TRUCK_BULK", "CAR06", 2, 1),
    ("SUP011", "PL01"): ("TRUCK_PNEUMATIC", "CAR04", 3, 2), ("SUP011", "PL02"): ("TRUCK_PNEUMATIC", "CAR04", 1, 2),
    ("SUP011", "PL03"): ("TRUCK_PNEUMATIC", "CAR04", 4, 2),
    ("SUP012", "PL01"): ("TRUCK", "CAR03", 2, 3), ("SUP012", "PL02"): ("TRUCK", "CAR05", 4, 3),
    ("SUP012", "PL03"): ("TRUCK", "CAR06", 5, 3),
    ("SUP013", "PL01"): ("TRUCK_BULK", "CAR03", 1, 1), ("SUP014", "PL02"): ("TRUCK_BULK", "CAR05", 1, 1),
    ("SUP021", "PL03"): ("TRUCK_BULK", "CAR06", 1, 1),
    ("SUP015", "PL01"): ("TRUCK_LTL", "CAR08", 2, 5), ("SUP016", "PL01"): ("TRUCK_LTL", "CAR08", 4, 7),
    ("SUP017", "PL01"): ("TRUCK", "CAR03", 2, 8), ("SUP017", "PL03"): ("TRUCK", "CAR06", 4, 8),
    ("SUP018", "PL01"): ("OCEAN_INTERMODAL", "CAR07", 28, 10), ("SUP018", "PL03"): ("OCEAN_INTERMODAL", "CAR07", 35, 10),
    ("SUP019", "PL01"): ("TRUCK_LTL", "CAR08", 3, 18), ("SUP019", "PL02"): ("TRUCK_LTL", "CAR08", 2, 18),
    ("SUP020", "PL01"): ("TRUCK_LTL", "CAR08", 2, 22), ("SUP020", "PL02"): ("TRUCK_LTL", "CAR08", 4, 22),
}

# Approved sources with quota share (plant, material) -> [(supplier, quota)]
QUOTA = {
    ("PL01", "RM-SAND-STD"): [("SUP001", .6), ("SUP002", .4)],
    ("PL01", "RM-SODA"): [("SUP006", .5), ("SUP007", .5)],
    ("PL01", "RM-DOLO"): [("SUP008", 1)], ("PL01", "RM-LIME"): [("SUP008", 1)],
    ("PL01", "RM-SALT"): [("SUP011", 1)], ("PL01", "RM-CARB"): [("SUP012", 1)],
    ("PL01", "RM-CULL"): [("SUP013", 1)], ("PL01", "RM-FEOX"): [("SUP015", 1)],
    ("PL01", "RM-COOX"): [("SUP015", 1)], ("PL01", "RM-SELN"): [("SUP016", 1)],
    ("PL01", "RM-PVB"): [("SUP017", .7), ("SUP018", .3)],
    ("PL01", "RM-TGT-AG"): [("SUP019", .65), ("SUP020", .35)],
    ("PL01", "RM-TGT-ZNSN"): [("SUP019", .65), ("SUP020", .35)],
    ("PL02", "RM-SAND-STD"): [("SUP003", .75), ("SUP001", .25)],
    ("PL02", "RM-SODA"): [("SUP006", .6), ("SUP007", .4)],
    ("PL02", "RM-DOLO"): [("SUP009", 1)], ("PL02", "RM-LIME"): [("SUP009", 1)],
    ("PL02", "RM-SALT"): [("SUP011", 1)], ("PL02", "RM-CARB"): [("SUP012", 1)],
    ("PL02", "RM-CULL"): [("SUP014", 1)],
    ("PL02", "RM-TGT-AG"): [("SUP019", .65), ("SUP020", .35)],
    ("PL02", "RM-TGT-ZNSN"): [("SUP019", .65), ("SUP020", .35)],
    ("PL03", "RM-SAND-STD"): [("SUP004", 1)],
    ("PL03", "RM-SAND-LI"): [("SUP005", .8), ("SUP001", .2)],
    ("PL03", "RM-SODA"): [("SUP006", .7), ("SUP007", .3)],
    ("PL03", "RM-DOLO"): [("SUP010", 1)], ("PL03", "RM-LIME"): [("SUP010", 1)],
    ("PL03", "RM-SALT"): [("SUP011", 1)], ("PL03", "RM-CARB"): [("SUP012", 1)],
    ("PL03", "RM-CULL"): [("SUP021", 1)],
    ("PL03", "RM-PVB"): [("SUP017", .6), ("SUP018", .4)],
}
# order rounding lot, max consignment size, order cover days, safety stock days
POLICY = {
    "RM-SAND-STD": (100, 1000, 7, 5), "RM-SAND-LI": (100, 600, 10, 6), "RM-SODA": (90, 900, 10, 6),
    "RM-DOLO": (25, 250, 10, 5), "RM-LIME": (25, 250, 10, 5), "RM-SALT": (25, 25, 20, 10),
    "RM-CARB": (22, 22, 45, 20), "RM-CULL": (25, 250, 7, 3), "RM-FEOX": (1000, 5000, 45, 20),
    "RM-COOX": (25, 200, 60, 30), "RM-SELN": (25, 100, 60, 30), "RM-PVB": (802.5, 32100, 21, 15),
    "RM-TGT-AG": (40, 160, 30, 20), "RM-TGT-ZNSN": (70, 560, 30, 15),
}
SHIP_SIZE_OVERRIDE = {("SUP002", "RM-SAND-STD"): 500}
BULK = {"SILO", "BIN", "STOCKPILE"}

EMPLOYEES = [
    ("E001", "Rachel Moreno", "Procurement Manager", "HQ", "APPROVER_L2"),
    ("E002", "David Okafor", "VP Supply Chain", "HQ", "APPROVER_L3"),
    ("E003", "Priya Natarajan", "Category Buyer - Bulk Minerals & Cullet", "HQ", "BUYER"),
    ("E004", "Tom Becker", "Category Buyer - Chemicals & Colorants", "HQ", "BUYER"),
    ("E005", "Lauren Fitch", "Category Buyer - Interlayers & Coating Materials", "HQ", "BUYER"),
    ("E006", "Marcus Hale", "Purchasing Team Lead", "HQ", "APPROVER_L1"),
]
for p, names in {"PL01": ["Kevin Shaw", "Angela Ruiz", "Brian Nguyen", "Steve Kowalski", "Dana Price", "Michelle Grant"],
                 "PL02": ["Carlos Mendoza", "Jasmine Patel", "Tyler Brooks", "Luis Ortega", "Hannah Webb", "Robert Kim"],
                 "PL03": ["Emily Tran", "Daniel Singh", "Sofia Alvarez", "Jake Morrison", "Nina Castillo", "Gregory Hall"]}.items():
    n = p[-1]
    roles = [("Materials Planner", "PLANNER"), ("QC Lab Analyst", "QC_ANALYST"), ("QC Lab Analyst", "QC_ANALYST"),
             ("Receiving Clerk", "RECEIVER"), ("Receiving Clerk", "RECEIVER"), ("Plant Quality Manager", "QUALITY_MANAGER")]
    for i, (nm, (title, fn)) in enumerate(zip(names, roles)):
        EMPLOYEES.append((f"E{n}0{i + 1}", nm, title, p, fn))
EMP_BY = defaultdict(list)
for e in EMPLOYEES:
    EMP_BY[(e[3], e[4])].append(e[0])
BUYER_OF = {"BATCH_MAJOR": "E003", "CULLET": "E003", "BATCH_MINOR": "E004", "COLORANT": "E004",
            "INTERLAYER": "E005", "COATING_TARGET": "E005"}
BUYER_OF_MAT = lambda m: "E004" if m == "RM-SODA" else BUYER_OF[MAT[m]["group"]]


def S(code, name, uom, lsl, usl, tgt, sd, dlsl, dusl, allow, method):
    return dict(code=code, name=name, uom=uom, lsl=lsl, usl=usl, tgt=tgt, sd=sd, dlsl=dlsl, dusl=dusl,
                allow=allow, method=method)


MOIST = lambda usl, tgt, sd, dev: S("MOIST", "Moisture", "%", None, usl, tgt, sd, None, dev, True, "Loss on drying")
SPECS = {
    "RM-SAND-STD": [S("SIO2", "Silica (SiO2)", "%", 99.0, None, 99.45, .13, 98.8, None, True, "XRF"),
                    S("FE2O3", "Iron oxide (Fe2O3)", "%", None, .040, .0330, .0020, None, .045, True, "XRF"),
                    S("AL2O3", "Alumina (Al2O3)", "%", None, .60, .30, .08, None, .70, True, "XRF"),
                    MOIST(5.0, 3.6, .40, 6.0),
                    S("OVR30", "Oversize +30 mesh (>600 um)", "%", None, .50, .15, .09, None, 1.0, True, "Sieve analysis"),
                    S("FIN140", "Fines -140 mesh (<106 um)", "%", None, 2.0, .9, .30, None, 3.0, True, "Sieve analysis")],
    "RM-SAND-LI": [S("SIO2", "Silica (SiO2)", "%", 99.6, None, 99.80, .05, 99.5, None, True, "XRF"),
                   S("FE2O3", "Iron oxide (Fe2O3)", "%", None, .012, .0094, .0007, None, None, False, "XRF"),
                   S("AL2O3", "Alumina (Al2O3)", "%", None, .25, .12, .035, None, .30, True, "XRF"),
                   MOIST(5.0, 3.5, .40, 6.0),
                   S("OVR30", "Oversize +30 mesh (>600 um)", "%", None, .30, .08, .06, None, .6, True, "Sieve analysis")],
    "RM-SODA": [S("NA2CO3", "Sodium carbonate assay", "%", 99.2, None, 99.60, .10, 99.0, None, True, "Titration"),
                S("NACL", "Chloride as NaCl", "%", None, .15, .07, .022, None, .25, True, "Titration"),
                S("FE2O3", "Iron as Fe2O3", "ppm", None, 30, 12, 5, None, 40, True, "ICP-OES"),
                S("BULKDEN", "Bulk density", "g/cm3", .95, 1.12, 1.03, .025, .92, 1.15, True, "Bulk density cup"),
                S("OVR20", "Oversize +20 mesh", "%", None, 1.0, .3, .2, None, 2.0, True, "Sieve analysis")],
    "RM-DOLO": [S("MGO", "Magnesia (MgO)", "%", 20.5, None, 21.2, .22, 20.0, None, True, "XRF"),
                S("CAO", "Lime (CaO)", "%", 29.5, 31.5, 30.4, .30, 29.0, 32.0, True, "XRF"),
                S("FE2O3", "Iron oxide (Fe2O3)", "%", None, .10, .060, .012, None, .14, True, "XRF"),
                MOIST(1.0, .45, .16, 1.5),
                S("OVR8", "Oversize +8 mesh", "%", None, 1.0, .3, .18, None, 2.0, True, "Sieve analysis")],
    "RM-LIME": [S("CAO", "Lime (CaO)", "%", 54.5, None, 55.2, .20, 54.0, None, True, "XRF"),
                S("MGO", "Magnesia (MgO)", "%", None, 1.5, .8, .20, None, 2.0, True, "XRF"),
                S("FE2O3", "Iron oxide (Fe2O3)", "%", None, .07, .035, .010, None, .10, True, "XRF"),
                MOIST(1.0, .4, .16, 1.5)],
    "RM-SALT": [S("NA2SO4", "Sodium sulfate assay", "%", 99.0, None, 99.4, .12, 98.7, None, True, "Gravimetric"),
                MOIST(.5, .15, .09, 1.0),
                S("FE2O3", "Iron as Fe2O3", "ppm", None, 50, 15, 8, None, 70, True, "ICP-OES")],
    "RM-CARB": [S("FIXC", "Fixed carbon", "%", 85, None, 88, .9, 83, None, True, "Proximate analysis"),
                S("ASH", "Ash", "%", None, 10, 7, .9, None, 12, True, "Proximate analysis"),
                S("SULF", "Sulfur", "%", None, .8, .55, .07, None, 1.0, True, "Combustion IR"),
                MOIST(5, 2.5, .7, 7)],
    "RM-CULL": [S("CSP", "Ceramics, stones & porcelain", "g/t", None, 20, 6, 3.5, None, None, False, "Optical sorter audit"),
                S("METAL", "Metals (ferrous + non-ferrous)", "g/t", None, 5, 1.2, .9, None, 8, True, "Magnetic / eddy-current audit"),
                S("COLMIX", "Non-flint colour contamination", "%", None, 1.0, .30, .18, None, 2.0, True, "Visual sort"),
                MOIST(2.0, .8, .32, 3.0),
                S("ORG", "Organics (paper, plastic)", "%", None, .10, .03, .018, None, .20, True, "Loss on ignition")],
    "RM-FEOX": [S("FE2O3", "Fe2O3 assay", "%", 95, None, 97, .55, 94, None, True, "Titration"), MOIST(1.0, .4, .14, 1.5)],
    "RM-COOX": [S("CO", "Cobalt content", "%", 71, None, 72.5, .35, 70.5, None, True, "ICP-OES"),
                S("NI", "Nickel", "ppm", None, 500, 200, 70, None, 700, True, "ICP-OES")],
    "RM-SELN": [S("SE", "Selenium assay", "%", 99.5, None, 99.85, .07, 99.3, None, True, "ICP-OES")],
    "RM-PVB": [S("THK", "Thickness", "mm", .36, .40, .380, .0055, .355, .405, True, "Micrometer"),
               S("H2O", "Moisture content", "%", .35, .55, .45, .028, None, None, False, "Karl Fischer"),
               S("HAZE", "Haze", "%", None, .5, .20, .07, None, .7, True, "Hazemeter"),
               S("WIDTH", "Roll width", "mm", 3208, 3215, 3211.0, .9, 3206, 3217, True, "Steel tape")],
    "RM-TGT-AG": [S("PUR", "Silver purity", "%", 99.99, None, 99.995, .0015, None, None, False, "GDMS"),
                  S("RDEN", "Relative density", "%", 98, None, 99.2, .3, 97.5, None, True, "Archimedes"),
                  S("BOND", "Bond coverage (ultrasonic)", "%", 95, None, 98.5, .8, 93, None, True, "Ultrasonic C-scan")],
    "RM-TGT-ZNSN": [S("SN", "Tin content", "wt%", 48, 52, 50, .45, 47.5, 52.5, True, "XRF"),
                    S("RDEN", "Relative density", "%", 96, None, 97.8, .45, 95.5, None, True, "Archimedes"),
                    S("BOND", "Bond coverage (ultrasonic)", "%", 95, None, 98.3, .8, 93, None, True, "Ultrasonic C-scan")],
}
# Persistent supplier-specific process biases (in units of the characteristic)
SUP_BIAS = {("SUP003", "MOIST"): .55, ("SUP021", "CSP"): 4.0, ("SUP021", "METAL"): .6, ("SUP009", "FE2O3"): .008,
            ("SUP012", "ASH"): .8, ("SUP020", "BOND"): -.9, ("SUP014", "COLMIX"): .12, ("SUP010", "MOIST"): .15}

# =====================================================================================
# PLAN: float campaigns + finishing days through PLAN_END
# =====================================================================================
def month_plan(line, y, m):
    days_in = (dt.date(y + (m == 12), m % 12 + 1, 1) - dt.timedelta(1)).day
    src = CAMPAIGN[line].get(m, CAMPAIGN[line][9])
    tot = sum(d for _, d in src)
    out, acc = [], 0
    for i, (p, d) in enumerate(src):
        n = days_in - acc if i == len(src) - 1 else round(d * days_in / tot)
        out += [p] * n
        acc += n
    return out


FLOAT_PLAN = {}  # line -> {date: product}
for line in CAMPAIGN:
    FLOAT_PLAN[line] = {}
    for (y, m) in [(2026, 7), (2026, 8), (2026, 9), (2026, 10), (2026, 11)]:
        for i, p in enumerate(month_plan(line, y, m)):
            FLOAT_PLAN[line][dt.date(y, m, i + 1)] = p


def finishing_works(line, d):
    if line.startswith("LAM"):
        if d in HOLIDAYS:
            return False
        return d.weekday() < (6 if line == "LAM-PL01-1" else 5)
    return True


def coater_downtime(line, d):
    # Planned target change / chamber clean every 14 days (12 h)
    off = 3 if line == "CTR-PL01-1" else 8
    return 12.0 if (d - START).days % 14 == off else 0.0


PLANNED_PULL = {l: LINE[l]["cap"] * 0.97 for l in FLOAT_PLAN}
# planned material usage per (plant, material, date)
PLAN_USE = defaultdict(float)
for l, sched in FLOAT_PLAN.items():
    pl = LINE[l]["plant_id"]
    for d, p in sched.items():
        for m, q in RECIPE[p].items():
            PLAN_USE[(pl, m, d)] += q * PLANNED_PULL[l]
for l, p in FINISH_LINE_PRODUCT.items():
    pl = LINE[l]["plant_id"]
    for d in PLAN_DAYS:
        if finishing_works(l, d):
            good = LINE[l]["cap"] * 0.92 * (1 - coater_downtime(l, d) / 24)
            for m, q in FINISH_BOM[p].items():
                if m != "substrate":
                    PLAN_USE[(pl, m, d)] += q * good


def usage(pl, m, d0, ndays):
    return sum(PLAN_USE.get((pl, m, d0 + dt.timedelta(i)), 0.0) for i in range(ndays))


PM = sorted(QUOTA.keys())
AVG_USE = {k: usage(k[0], k[1], START, 92) / 92 for k in PM}


def plan_lt(k):
    return sum(q * sum(LANES[(s, k[0])][2:4]) for s, q in QUOTA[k]) + 2  # +2: ack buffer + QI release


def run_rate(k):
    vals = [PLAN_USE.get((k[0], k[1], d), 0.0) for d in PLAN_DAYS]
    nz = [v for v in vals if v > 0]
    return sum(nz) / len(nz) if nz else 0.0


SS = {k: run_rate(k) * POLICY[k[1]][3] for k in PM}

# =====================================================================================
# RECORD STORES
# =====================================================================================
T = defaultdict(list)
seq = defaultdict(int)


def nid(kind, fmt):
    seq[kind] += 1
    return fmt.format(seq[kind])


evq, ctr = [], itertools.count()


def push(ts, kind, payload):
    heapq.heappush(evq, (ts, next(ctr), kind, payload))


# ---------------- Contracts ----------------
CONTRACTS = {}  # (sup, plant, mat) -> list of contract dicts
for (pl, m), lst in QUOTA.items():
    for s, q in lst:
        base = MAT[m]["price"]
        lt = sum(LANES[(s, pl)][2:4])
        price = base * (1 + rng.uniform(-.06, .08))
        if SUP[s]["ccy"] == "EUR":
            price = base / 1.12 * (1 + rng.uniform(-.10, -.04))
        windows = [(dt.date(2026, 1, 1), dt.date(2026, 12, 31), price)]
        if s == "SUP018":
            windows = [(dt.date(2026, 1, 1), dt.date(2026, 7, 31), price),
                       (dt.date(2026, 8, 1), dt.date(2026, 12, 31), price * 1.06)]
        if s == "SUP017":
            windows = [(dt.date(2026, 1, 1), dt.date(2026, 8, 31), price),
                       (dt.date(2026, 9, 1), dt.date(2026, 12, 31), price * 1.03)]
        for vf, vt, pr in windows:
            cid = nid("contract", "CTR-2026-{:04d}")
            row = dict(contract_id=cid, supplier_id=s, plant_id=pl, material_id=m, valid_from=vf, valid_to=vt,
                       contract_price=round(pr, 4), currency=SUP[s]["ccy"], price_uom=MAT[m]["uom"],
                       incoterm="CPT" if SUP[s]["country"] == "US" else "CIF", quota_share_pct=round(q * 100, 1),
                       std_lead_time_days=lt, min_order_qty=POLICY[m][0], under_delivery_tol_pct=5.0,
                       over_delivery_tol_pct=5.0 if MAT[m]["storage"] in BULK else 0.0,
                       contract_status="ACTIVE", signed_by="E001")
            T["supplier_material_contracts"].append(row)
            CONTRACTS.setdefault((s, pl, m), []).append(row)


def contract_for(s, pl, m, d):
    for c in CONTRACTS[(s, pl, m)]:
        if c["valid_from"] <= d <= c["valid_to"]:
            return c


# ---------------- Inventory model ----------------
STOCK = defaultdict(lambda: {"UNR": deque(), "QI": {}, "BLK": {}})
BATCH_INFO = {}     # batch -> dict(supplier, gr_id, deviation_char)
SLOC = {}
for (pl, m) in PM:
    st = MAT[m]["storage"]
    SLOC[(pl, m)] = {"SILO": f"{pl}-SILO-{m.split('-')[1]}", "BIN": f"{pl}-BIN-{m.split('-')[1]}",
                     "STOCKPILE": f"{pl}-YARD-CULLET", "WAREHOUSE": f"{pl}-WH-01",
                     "CLIMATE_WAREHOUSE": f"{pl}-WH-CLIM"}[st]


def txn(ts, pl, m, batch, stype, mvt, desc, qty, ref_type, ref_id, mo=None, user=None, reason=None):
    T["inventory_transactions"].append(dict(
        txn_id=nid("txn", "IT-{:07d}"), txn_ts=ts, posting_date=ts.date(), plant_id=pl,
        storage_location_id=SLOC[(pl, m)], material_id=m, batch_id=batch,
        supplier_id=BATCH_INFO.get(batch, {}).get("supplier"), stock_type=stype, movement_type=mvt,
        movement_desc=desc, quantity=r3(qty), uom=MAT[m]["uom"], reference_doc_type=ref_type,
        reference_doc_id=ref_id, production_order_id=mo, posted_by=user, reason_text=reason))


def unr_total(pl, m):
    return sum(b[1] for b in STOCK[(pl, m)]["UNR"])


def qi_total(pl, m):
    return sum(STOCK[(pl, m)]["QI"].values())


SHORTAGES = []


def issue_fifo(ts, pl, m, qty, mo, user):
    """Goods issue 261 from unrestricted stock, oldest batch first. Returns list of batches used."""
    q = STOCK[(pl, m)]["UNR"]
    used, need = [], qty
    while need > 5e-4 and q:
        b = q[0]
        take = round(min(b[1], need), 3)
        txn(ts, pl, m, b[0], "UNRESTRICTED", "261", "Goods issue to production order", -take,
            "PRODUCTION_ORDER", mo, mo, user)
        used.append(b[0])
        b[1] -= take
        need -= take
        if b[1] <= 5e-4:
            q.popleft()
    if need > 1e-3:
        SHORTAGES.append((ts, pl, m, need))
    return used


# ---------------- Opening balances ----------------
for (pl, m) in PM:
    k = (pl, m)
    qty = SS[k] + usage(pl, m, START, int(round(plan_lt(k))) + POLICY[m][2] // 2)
    if AVG_USE[k] == 0:
        continue
    qty = math.ceil(qty / POLICY[m][0]) * POLICY[m][0]
    s0 = QUOTA[k][0][0]
    b = nid("batch", "B26{:07d}")
    BATCH_INFO[b] = dict(supplier=s0, gr_id=None, dev=None)
    STOCK[k]["UNR"].append([b, qty, s0])
    txn(OPEN_TS, pl, m, b, "UNRESTRICTED", "561", "Opening stock (carried forward from June close)", qty,
        "OPENING_BALANCE", f"OB-{pl}-{m}", None, "SYSTEM")

# =====================================================================================
# PURCHASING
# =====================================================================================
OPEN_SCHED = defaultdict(float)   # (pl, m) -> qty on open schedule lines (not yet arrived)
QUOTA_ALLOC = defaultdict(float)
LAST_EXPEDITE = {}
SHIPMENT_ROWS = {}
POLYLAM_FORCED = {"done": False}


def pick_supplier(k, exclude=None):
    best, bs = None, 1e18
    for s, q in QUOTA[k]:
        if s == exclude:
            continue
        sc = QUOTA_ALLOC[(k, s)] / q
        if sc < bs:
            best, bs = s, sc
    return best


def late_profile(s, ship_planned):
    """Supplier dispatch delay in days."""
    p = SUP[s]["p_late"]
    if s == "SUP007" and ship_planned >= dt.date(2026, 9, 1):
        return int(rng.integers(2, 6)) if rng.random() < .55 else (1 if rng.random() < .1 else 0)
    if rng.random() < p:
        return int(rng.choice([1, 1, 1, 2, 2, 3, 4]))
    if rng.random() < .04:
        return -1
    return 0


def transit_delay(mode, carrier):
    if mode == "OCEAN_INTERMODAL":
        return int(rng.integers(5, 10)) if rng.random() < .6 else int(rng.integers(0, 3))
    if mode == "RAIL":
        return int(rng.choice([1, 1, 2])) if rng.random() < .05 else 0
    return 1 if rng.random() < .04 else 0


def arrival_hour(mode):
    if mode == "RAIL":
        return rng.uniform(0, 24)
    return rng.uniform(6, 17.5)


def create_order(d, k, qty, expedite=False, exclude=None):
    pl, m = k
    s = pick_supplier(k, exclude) if not expedite else pick_supplier(k, exclude)
    if s is None:
        return
    QUOTA_ALLOC[(k, s)] += qty
    mode, car, transit, proc = LANES[(s, pl)]
    std_lt = transit + proc
    if expedite:
        proc = max(0, proc // 2)
        transit_eff = max(1, math.ceil(transit * .6))
        if mode == "RAIL":
            mode_eff = "TRUCK_PNEUMATIC" if m == "RM-SODA" else "TRUCK_BULK"
            car_eff = "CAR04" if m == "RM-SODA" else {"PL01": "CAR03", "PL02": "CAR05", "PL03": "CAR06"}[pl]
        else:
            mode_eff, car_eff = mode, car
    else:
        transit_eff, mode_eff, car_eff = transit, mode, car
    c = contract_for(s, pl, m, d)
    price = c["contract_price"]
    value = qty * price * (1.12 if c["currency"] == "EUR" else 1)

    # --- Purchase requisition & approval ---
    pr_ts = at(d, 7 + rng.uniform(.05, .4)) if not expedite else at(d, 7.5 + rng.uniform(0, 2))
    if expedite:
        lvl, appr, delay = "L2", "E001", rng.uniform(.3, 2.0)
    elif value < 100_000:
        lvl, appr, delay = "L1", "E006", rng.uniform(.5, 8)
    elif value < 500_000:
        lvl, appr, delay = "L2", "E001", rng.uniform(3, 26)
    else:
        lvl, appr, delay = "L3", "E002", rng.uniform(8, 44)
    appr_ts = pr_ts + dt.timedelta(hours=delay)
    po_ts = appr_ts + dt.timedelta(hours=rng.uniform(.2, 3.0))
    pr_id = nid("pr", "PR-{:07d}")
    po_id = nid("po", "45{:08d}")
    po_line_id = f"{po_id}-00010"
    buyer = BUYER_OF_MAT(m)
    ack_ts = po_ts + dt.timedelta(hours=float(rng.lognormal(math.log(SUP[s]["ack_h"]), .5)))
    if expedite:
        ack_ts = po_ts + dt.timedelta(hours=rng.uniform(.5, 4))

    lot, ship_max, cover, _ = POLICY[m]
    ship_max = SHIP_SIZE_OVERRIDE.get((s, m), ship_max)
    n = max(1, math.ceil(qty / ship_max - 1e-9))
    per = qty / n
    if MAT[m]["storage"] not in BULK:  # discrete units: keep whole lots per consignment
        lots = int(round(qty / lot))
        base_lots = [lots // n + (1 if i < lots % n else 0) for i in range(n)]
        qtys = [bl * lot for bl in base_lots]
    else:
        qtys = [per] * n
    ack_days = math.ceil((ack_ts - po_ts).total_seconds() / 86400)
    first_req = po_ts.date() + dt.timedelta(days=(max(std_lt, ack_days + transit + 1) + 1) if not expedite
                                            else proc + transit_eff + 1)
    spacing = 0 if expedite else (cover / n if n > 1 else 0)
    T["purchase_requisitions"].append(dict(
        pr_id=pr_id, pr_line_no=10, plant_id=pl, material_id=m, requested_qty=r3(qty), uom=MAT[m]["uom"],
        required_date=first_req, created_ts=pr_ts,
        created_by="MRP_BATCH" if not expedite else EMP_BY[(pl, "PLANNER")][0],
        source="MRP_REORDER_POINT" if not expedite else "PLANNER_EXPEDITE",
        priority="EXPEDITE" if expedite else "NORMAL", preferred_supplier_id=s,
        estimated_value_usd=round(value, 2), approval_level=lvl, approver_id=appr,
        approval_status="APPROVED", approved_ts=appr_ts, po_id=po_id, po_line_id=po_line_id))
    sched_rows, delivered_all, any_deliv = [], True, False
    for i, sq in enumerate(qtys):
        req = first_req + dt.timedelta(days=int(round(i * spacing)))
        push_days = int(rng.integers(1, 4)) if rng.random() < SUP[s]["p_push"] else 0
        if s == "SUP018" and push_days:
            push_days = int(rng.integers(3, 8))
        promised = req + dt.timedelta(days=push_days)
        if mode_eff != "RAIL" and promised.weekday() == 6:
            promised += dt.timedelta(days=1)
        sl_id = f"{po_line_id}-{i + 1:02d}"
        planned_ship = promised - dt.timedelta(days=transit_eff)
        delay = 0 if expedite else late_profile(s, planned_ship)
        ship_day = max(planned_ship + dt.timedelta(days=delay), (ack_ts + dt.timedelta(hours=4)).date())
        ship_ts = at(ship_day, rng.uniform(5, 18))
        tdelay = transit_delay(mode_eff, car_eff)
        arr_day = ship_day + dt.timedelta(days=transit_eff + tdelay)
        arr_ts = at(arr_day, arrival_hour(mode_eff))
        if mode_eff != "RAIL" and arr_ts.weekday() == 6:
            arr_ts = at(arr_day + dt.timedelta(days=1), rng.uniform(6, 10))
        if arr_ts < ship_ts + dt.timedelta(hours=4):
            arr_ts = ship_ts + dt.timedelta(hours=rng.uniform(4, 10))
        fill = 1.0
        if MAT[m]["storage"] in BULK:
            fill = float(rng.normal(1.0, .008))
            if rng.random() < .04:
                fill = float(rng.uniform(.86, .95))
        shipped = sq * fill
        sched_status = "OPEN"
        ack_ok = ack_ts <= END_TS
        sched_rows.append(dict(schedule_line_id=sl_id, po_line_id=po_line_id, po_id=po_id, schedule_line_no=i + 1,
                               scheduled_qty=r3(sq), uom=MAT[m]["uom"], requested_delivery_date=req,
                               promised_delivery_date=promised if ack_ok else None,
                               supplier_confirmed_ts=ack_ts if ack_ok else None))
        OPEN_SCHED[k] += sq
        if ship_ts <= END_TS:
            shp_id = nid("shp", "SHP-{:06d}")
            sb = f"{s[-3:]}-{ship_day:%y%m%d}-{int(rng.integers(100, 999))}"
            vehicle = {"RAIL": f"UNIT-{int(rng.integers(1000, 9999))}",
                       "OCEAN_INTERMODAL": f"BWOU{int(rng.integers(1000000, 9999999))}"}.get(
                mode_eff, f"TRK-{int(rng.integers(10000, 99999))}")
            asn_ts = ship_ts + dt.timedelta(hours=float(rng.uniform(.2, 6)) if rng.random() > .08 else
                                            float(rng.uniform(12, 40)))
            row = dict(shipment_id=shp_id, asn_number=f"ASN-{s[-3:]}-{seq['shp']:06d}", supplier_id=s,
                       po_id=po_id, po_line_id=po_line_id, schedule_line_id=sl_id, plant_id=pl, material_id=m,
                       carrier_id=car_eff, transport_mode=mode_eff, vehicle_or_container_id=vehicle,
                       bill_of_lading_no=f"BOL{int(rng.integers(10 ** 8, 10 ** 9))}", supplier_batch_no=sb,
                       shipped_qty=r3(shipped), uom=MAT[m]["uom"], planned_ship_date=planned_ship,
                       actual_ship_ts=ship_ts, asn_sent_ts=min(asn_ts, END_TS),
                       expected_arrival_date=promised, actual_arrival_ts=arr_ts if arr_ts <= END_TS else None,
                       shipment_status="DELIVERED" if arr_ts <= END_TS else "IN_TRANSIT")
            T["inbound_shipments"].append(row)
            SHIPMENT_ROWS[shp_id] = row
            sched_status = "IN_TRANSIT"
            if arr_ts <= END_TS:
                push(arr_ts, "ARRIVAL", dict(shp=shp_id, k=k, s=s, sq=sq, expedite=expedite))
                sched_status = "DELIVERED"
                any_deliv = True
            else:
                delivered_all = False
        else:
            delivered_all = False
        sched_rows[-1]["schedule_line_status"] = sched_status
    T["po_schedule_lines"].extend(sched_rows)
    status = "CLOSED" if delivered_all else ("PARTIALLY_DELIVERED" if any_deliv else "OPEN")
    T["purchase_orders"].append(dict(
        po_id=po_id, po_type="EXPEDITE" if expedite else "STANDARD", supplier_id=s, plant_id=pl,
        purchasing_org="CGC-US", buyer_id=buyer, created_ts=po_ts, released_ts=po_ts + dt.timedelta(minutes=int(rng.integers(2, 45))),
        supplier_ack_ts=ack_ts if ack_ts <= END_TS else None, currency=c["currency"], incoterm=c["incoterm"],
        payment_terms=SUP[s]["terms"], total_net_value=round(qty * price, 2), po_status=status))
    T["purchase_order_lines"].append(dict(
        po_line_id=po_line_id, po_id=po_id, line_no=10, pr_id=pr_id, material_id=m, plant_id=pl,
        contract_id=c["contract_id"], ordered_qty=r3(qty), uom=MAT[m]["uom"], unit_price=price,
        currency=c["currency"], net_value=round(qty * price, 2), requested_delivery_date=first_req,
        under_delivery_tol_pct=c["under_delivery_tol_pct"], over_delivery_tol_pct=c["over_delivery_tol_pct"],
        expedite_freight_flag=expedite, line_status=status))


# =====================================================================================
# QUALITY
# =====================================================================================
def gen_quality(s, pl, m, ship_date, shp_id):
    results, decision = [], "ACCEPT"
    worst = None
    forced_pvb = False
    if s == "SUP018" and not POLYLAM_FORCED["done"] and ship_date >= dt.date(2026, 7, 10):
        POLYLAM_FORCED["done"] = forced_pvb = True
    coa = rng.random() < SUP[s]["p_coa"]
    for sp in SPECS[m]:
        sd = sp["sd"] * SUP[s]["qsd"]
        mean = sp["tgt"] + SUP_BIAS.get((s, sp["code"]), 0.0)
        drift = s == "SUP002" and m == "RM-SAND-STD" and sp["code"] == "FE2O3" and \
            dt.date(2026, 8, 3) <= ship_date <= dt.date(2026, 8, 26)
        if drift:
            mean, sd = .0415, .0027
        val = float(rng.normal(mean, sd))
        if forced_pvb and sp["code"] == "H2O":
            val = .62
        if sp["code"] in ("CSP", "METAL", "ORG", "COLMIX", "NI", "FE2O3", "NACL", "OVR30", "OVR20", "OVR8", "FIN140", "HAZE"):
            val = max(val, sp["tgt"] * .1)
        if sp["code"] == "PUR":
            val = min(val, 99.9999)
        dec = 3 if sp["sd"] >= .1 else (4 if sp["sd"] >= .001 else 5)
        val = round(val, dec)
        lo_ok = sp["lsl"] is None or val >= sp["lsl"]
        hi_ok = sp["usl"] is None or val <= sp["usl"]
        if lo_ok and hi_ok:
            res = "PASS"
        else:
            in_dev = sp["allow"] and (sp["dlsl"] is None or val >= sp["dlsl"]) and \
                     (sp["dusl"] is None or val <= sp["dusl"]) and \
                     (lo_ok or sp["dlsl"] is not None) and (hi_ok or sp["dusl"] is not None)
            res = "OUT_OF_SPEC_MINOR" if in_dev else "OUT_OF_SPEC_MAJOR"
        if res == "OUT_OF_SPEC_MAJOR":
            decision, worst = "REJECT", sp["code"]
        elif res == "OUT_OF_SPEC_MINOR" and decision != "REJECT":
            decision, worst = "ACCEPT_WITH_DEVIATION", sp["code"]
        coa_val = None
        if coa:
            coa_val = val + float(rng.normal(0, sp["sd"] * .5))
            if drift:
                coa_val = min(val, float(rng.normal(.0378, .0008)))
            if forced_pvb and sp["code"] == "H2O":
                coa_val = .49
            coa_val = round(coa_val, dec)
        results.append(dict(sp=sp, val=val, res=res, coa=coa_val))
    return results, decision, worst, coa


DEFECT_CAT = {"CSP": "CONTAMINATION", "METAL": "CONTAMINATION", "ORG": "CONTAMINATION", "COLMIX": "CONTAMINATION",
              "MOIST": "PHYSICAL", "H2O": "PHYSICAL", "OVR30": "PHYSICAL", "OVR20": "PHYSICAL", "OVR8": "PHYSICAL",
              "FIN140": "PHYSICAL", "BULKDEN": "PHYSICAL", "THK": "DIMENSIONAL", "WIDTH": "DIMENSIONAL",
              "BOND": "PHYSICAL", "RDEN": "PHYSICAL", "HAZE": "OPTICAL"}
ROOT_CAUSE = {
    ("SUP002", "FE2O3"): "Mining moved to lower bench of Pit 3 with higher heavy-mineral content; magnetic separator capacity insufficient",
    ("SUP018", "H2O"): "Container humidity control failure during ocean transit; interleaf packaging seal compromised",
    ("SUP003", "MOIST"): "Stockpile exposed to rain; dewatering screen bypassed during high-throughput shift",
    ("SUP021", "CSP"): "Optical sorter reject channel misaligned after maintenance",
}


def on_arrival(ts, p):
    shp = SHIPMENT_ROWS[p["shp"]]
    pl, m = p["k"]
    s = p["s"]
    OPEN_SCHED[(pl, m)] -= p["sq"]
    shipped = shp["shipped_qty"]
    if MAT[m]["storage"] in BULK:
        recv = shipped * float(rng.normal(1.0, .0025))
        if s == "SUP014":
            recv = shipped * (1 - float(rng.uniform(0, .035)))   # weighbridge vs supplier scale (wet cullet)
    else:
        recv = shipped
    recv = round(recv, 3)
    damage = False
    if m == "RM-PVB" and rng.random() < .05:
        recv -= 802.5
        damage = True
    gr_ts = ts + dt.timedelta(hours=float(rng.uniform(.5, 3.5)))
    gr_id = nid("gr", "50{:08d}")
    batch = nid("batch", "B26{:07d}")
    rec_by = rng.choice(EMP_BY[(pl, "RECEIVER")])
    T["goods_receipts"].append(dict(
        gr_id=gr_id, gr_line_no=1, shipment_id=shp["shipment_id"], po_id=shp["po_id"],
        po_line_id=shp["po_line_id"], schedule_line_id=shp["schedule_line_id"], supplier_id=s, plant_id=pl,
        storage_location_id=SLOC[(pl, m)], material_id=m, batch_id=batch, supplier_batch_no=shp["supplier_batch_no"],
        received_qty=r3(recv), uom=MAT[m]["uom"], gr_ts=gr_ts, received_by=rec_by,
        weighbridge_ticket_no=f"WB-{pl}-{int(rng.integers(100000, 999999))}" if MAT[m]["storage"] in BULK else None,
        packaging_damage_flag=damage, movement_type="101", stock_type="QUALITY_INSPECTION"))
    BATCH_INFO[batch] = dict(supplier=s, gr_id=gr_id, dev=None)
    STOCK[(pl, m)]["QI"][batch] = recv
    txn(gr_ts, pl, m, batch, "QUALITY_INSPECTION", "101", "Goods receipt for purchase order into QI stock",
        recv, "GOODS_RECEIPT", gr_id, None, rec_by)

    # --- inspection lot ---
    results, decision, worst, coa = gen_quality(s, pl, m, shp["actual_ship_ts"].date(), shp["shipment_id"])
    lot_id = nid("lot", "89{:010d}")
    analyst = rng.choice(EMP_BY[(pl, "QC_ANALYST")])
    st = gr_ts + dt.timedelta(hours=float(rng.uniform(.3, 2.5)))
    dur = {"COATING_TARGET": (20, 44), "INTERLAYER": (4, 10), "COLORANT": (6, 20)}.get(MAT[m]["group"], (2.5, 7))
    en = st + dt.timedelta(hours=float(rng.uniform(*dur)))
    ud = en + dt.timedelta(hours=float(rng.uniform(.2, 2.0)))
    qm = EMP_BY[(pl, "QUALITY_MANAGER")][0]
    ud_by = qm if decision != "ACCEPT" else analyst
    acc = recv if decision != "REJECT" else 0.0
    T["quality_inspection_lots"].append(dict(
        inspection_lot_id=lot_id, gr_id=gr_id, shipment_id=shp["shipment_id"], plant_id=pl, material_id=m,
        supplier_id=s, batch_id=batch, lot_qty=r3(recv), uom=MAT[m]["uom"], inspection_type="INCOMING_GOODS",
        sample_count=int(rng.integers(2, 6)) if MAT[m]["storage"] in BULK else int(rng.integers(1, 3)),
        coa_received_flag=coa, lot_created_ts=gr_ts, inspection_start_ts=st, inspection_end_ts=en,
        usage_decision=decision, usage_decision_ts=ud, usage_decision_by=ud_by,
        accepted_qty=r3(acc), rejected_qty=r3(recv - acc), inspected_by=analyst))
    for i, r in enumerate(results):
        sp = r["sp"]
        T["quality_inspection_results"].append(dict(
            result_id=f"{lot_id}-{i + 1:02d}", inspection_lot_id=lot_id, characteristic_code=sp["code"],
            characteristic_name=sp["name"], uom=sp["uom"], lower_spec_limit=sp["lsl"], upper_spec_limit=sp["usl"],
            target_value=sp["tgt"], measured_value=r["val"], supplier_coa_value=r["coa"], result_status=r["res"],
            test_method=sp["method"], tested_ts=st + (en - st) * (i + 1) / (len(results) + 1), tested_by=analyst))
    if decision == "ACCEPT_WITH_DEVIATION" and m == "RM-SAND-STD":
        BATCH_INFO[batch]["dev"] = worst
    push(ud, "UD", dict(k=(pl, m), batch=batch, decision=decision, lot=lot_id, gr=gr_id, s=s, qty=recv,
                        worst=worst, results=results, by=ud_by, shp=shp["shipment_id"]))

    # --- invoice (supplier invoices on dispatch) ---
    c = contract_for(s, pl, m, dt.date.fromisoformat(str(T_PO_DATE[shp["po_id"]])))
    inv_date = shp["actual_ship_ts"].date() + dt.timedelta(days=int(rng.integers(0, 3)))
    if inv_date <= END:
        inv_qty = shipped
        price = c["contract_price"]
        surcharge = 0.0
        if s == "SUP011" and rng.random() < .3:
            surcharge = round(inv_qty * price * .045, 2)
        freight = round(inv_qty * price * .18, 2) if p["expedite"] else 0.0
        if s == "SUP018" and rng.random() < .0:
            pass
        if not p["expedite"] and rng.random() < .015:
            price = round(price * 1.02, 4)  # occasional price-key error by supplier
        amt = round(inv_qty * price, 2)
        qty_var = abs(inv_qty - recv) / max(recv, 1e-9) > .01
        price_var = price != c["contract_price"] or surcharge > 0
        match = "MATCHED" if not (qty_var or price_var) else ("QTY_VARIANCE" if qty_var and not price_var else
                                                             ("PRICE_VARIANCE" if price_var and not qty_var else "QTY_AND_PRICE_VARIANCE"))
        due = inv_date + dt.timedelta(days=TERMS_DAYS[SUP[s]["terms"]])
        fx = 1.12 if c["currency"] == "EUR" else 1.0
        total = amt + surcharge + freight
        paid = None
        if match == "MATCHED" and due <= END:
            paid = due + dt.timedelta(days=int(rng.integers(-2, 4)))
            paid = paid if paid <= END else None
        T["supplier_invoices"].append(dict(
            invoice_id=nid("inv", "51{:08d}"), document_type="INVOICE",
            supplier_invoice_no=f"{SUP[s]['name'].split()[0][:4].upper()}-{inv_date:%y}{int(rng.integers(10000, 99999))}",
            supplier_id=s, plant_id=pl, po_id=shp["po_id"], po_line_id=shp["po_line_id"], gr_id=gr_id,
            shipment_id=shp["shipment_id"], material_id=m, invoice_date=inv_date,
            received_ts=at(inv_date, rng.uniform(8, 17)), invoiced_qty=r3(inv_qty), uom=MAT[m]["uom"],
            unit_price=price, line_amount=amt, surcharge_amount=surcharge, expedite_freight_amount=freight,
            total_amount=round(total, 2), currency=c["currency"], fx_rate_to_usd=fx,
            total_amount_usd=round(total * fx, 2), payment_terms=SUP[s]["terms"], due_date=due,
            match_status=match, payment_status="PAID" if paid else ("BLOCKED" if match != "MATCHED" else "OPEN"),
            paid_date=paid))


T_PO_DATE = {}


def on_ud(ts, p):
    pl, m = p["k"]
    b, qty = p["batch"], p["qty"]
    STOCK[(pl, m)]["QI"].pop(b, None)
    if p["decision"] == "REJECT":
        txn(ts, pl, m, b, "QUALITY_INSPECTION", "350", "Transfer QI to blocked stock (usage decision: reject)", -qty,
            "INSPECTION_LOT", p["lot"], None, p["by"])
        txn(ts, pl, m, b, "BLOCKED", "350", "Transfer QI to blocked stock (usage decision: reject)", qty,
            "INSPECTION_LOT", p["lot"], None, p["by"])
        STOCK[(pl, m)]["BLK"][b] = qty
    else:
        desc = "Release QI to unrestricted" + (" under deviation" if p["decision"] == "ACCEPT_WITH_DEVIATION" else "")
        txn(ts, pl, m, b, "QUALITY_INSPECTION", "321", desc, -qty, "INSPECTION_LOT", p["lot"], None, p["by"])
        txn(ts, pl, m, b, "UNRESTRICTED", "321", desc, qty, "INSPECTION_LOT", p["lot"], None, p["by"])
        STOCK[(pl, m)]["UNR"].append([b, qty, p["s"]])
    if p["decision"] != "ACCEPT":
        s = p["s"]
        r = next(x for x in p["results"] if x["sp"]["code"] == p["worst"])
        major = p["decision"] == "REJECT"
        ncr_id = nid("ncr", "NCR-2026-{:04d}")
        notified = ts + dt.timedelta(hours=float(rng.uniform(1, 8)))
        resp_h = float(rng.lognormal(math.log(30 if SUP[s]["tier"] == "STRATEGIC" else 60), .45))
        if s == "SUP003":
            resp_h *= 1.8
        response = notified + dt.timedelta(hours=resp_h)
        capa_due = (notified + dt.timedelta(days=30)).date() if major or (s == "SUP002") else None
        capa_closed = None
        if capa_due:
            close = notified + dt.timedelta(days=float(rng.uniform(14, 40)))
            capa_closed = close.date() if close <= END_TS else None
        root = ROOT_CAUSE.get((s, p["worst"]), "Process variation at supplier; under investigation")
        cost = 0.0
        if major:
            lane = LANES[(s, pl)]
            cost = round(qty * MAT[m]["price"] * (.12 if lane[0] in ("RAIL", "TRUCK_BULK") else .04) + 850, 2)
        T["nonconformance_reports"].append(dict(
            ncr_id=ncr_id, inspection_lot_id=p["lot"], gr_id=p["gr"], shipment_id=p["shp"], supplier_id=s,
            plant_id=pl, material_id=m, batch_id=b, defect_characteristic=p["worst"],
            defect_category=DEFECT_CAT.get(p["worst"], "CHEMICAL"), severity="MAJOR" if major else "MINOR",
            measured_value=r["val"], spec_limit=r["sp"]["usl"] if r["sp"]["usl"] is not None and r["val"] > r["sp"]["usl"] else r["sp"]["lsl"],
            affected_qty=r3(qty), uom=MAT[m]["uom"],
            disposition="RETURN_TO_SUPPLIER" if major else "USE_AS_IS_UNDER_DEVIATION",
            ncr_created_ts=ts, created_by=p["by"], supplier_notified_ts=notified,
            supplier_response_ts=response if response <= END_TS else None,
            supplier_root_cause=root if response <= END_TS else None,
            capa_required=capa_due is not None, capa_due_date=capa_due, capa_closed_date=capa_closed,
            cost_of_poor_quality_usd=cost,
            ncr_status="CLOSED" if (capa_closed or (capa_due is None and response <= END_TS)) else "OPEN"))
        if major:
            push(ts + dt.timedelta(days=float(rng.uniform(1, 5))), "RTV", dict(k=(pl, m), batch=b, qty=qty, ncr=ncr_id, s=s))


def on_rtv(ts, p):
    pl, m = p["k"]
    STOCK[(pl, m)]["BLK"].pop(p["batch"], None)
    rec = rng.choice(EMP_BY[(pl, "RECEIVER")])
    txn(ts, pl, m, p["batch"], "BLOCKED", "122", "Return delivery to vendor", -p["qty"], "NCR", p["ncr"], None, rec)
    # credit memo
    inv = next((i for i in T["supplier_invoices"] if i["gr_id"] == BATCH_INFO[p["batch"]]["gr_id"]), None)
    if inv and ts.date() <= END:
        cm_date = ts.date() + dt.timedelta(days=int(rng.integers(2, 10)))
        if cm_date <= END:
            T["supplier_invoices"].append(dict(inv, invoice_id=nid("inv", "51{:08d}"), document_type="CREDIT_MEMO",
                                               supplier_invoice_no=inv["supplier_invoice_no"] + "-CR", invoice_date=cm_date,
                                               received_ts=at(cm_date, 10), invoiced_qty=-inv["invoiced_qty"],
                                               line_amount=-inv["line_amount"], surcharge_amount=-inv["surcharge_amount"],
                                               expedite_freight_amount=-inv["expedite_freight_amount"],
                                               total_amount=-inv["total_amount"], total_amount_usd=-inv["total_amount_usd"],
                                               match_status="MATCHED", payment_status="OFFSET", paid_date=None))
        inv["payment_status"] = "BLOCKED"
        inv["paid_date"] = None


# =====================================================================================
# PRODUCTION
# =====================================================================================
FLOAT_DOWNTIME = {}
for l in FLOAT_PLAN:
    for mth in (7, 8, 9):
        d = dt.date(2026, mth, int(rng.integers(2, 28)))
        FLOAT_DOWNTIME[(l, d)] = (round(float(rng.uniform(2, 8)), 1),
                                  str(rng.choice(["BATCH_CHARGER_FAULT", "TIN_BATH_MAINTENANCE", "LEHR_ROLLER_CHANGE",
                                                  "CUTTING_LINE_FAULT", "FURNACE_COMBUSTION_TRIP"])))
TRANSITION = {("CLEAR", "TINTED"): [.10, .05], ("TINTED", "CLEAR"): [.12, .06, .02],
              ("CLEAR", "LOW_IRON"): [.14, .08, .04], ("LOW_IRON", "CLEAR"): [.06, .02]}
ORDERS = {}
CAMPAIGN_ID = {}


def campaign_id(l, d, p):
    prev = FLOAT_PLAN[l].get(d - dt.timedelta(1))
    if prev != p or (l, p) not in CAMPAIGN_ID:
        CAMPAIGN_ID[(l, p)] = f"CMP-{l}-{d:%y%m%d}"
    return CAMPAIGN_ID[(l, p)]


def transition_penalty(l, d, p):
    # walk back to find days since campaign start and previous product
    k, cur = 0, d
    while FLOAT_PLAN[l].get(cur - dt.timedelta(1)) == p:
        cur -= dt.timedelta(1)
        k += 1
    prev = FLOAT_PLAN[l].get(cur - dt.timedelta(1))
    if prev is None or prev == p:
        return 0.0, False
    pt = (PROD[prev]["glass_type"], PROD[p]["glass_type"])
    seqp = TRANSITION.get(pt, [.02])
    return (seqp[k] if k < len(seqp) else 0.0), k < len(seqp)


def start_float(ts, l):
    d = ts.date()
    p = FLOAT_PLAN[l][d]
    pl = LINE[l]["plant_id"]
    mo = nid("mo", "MO-{:07d}")
    pull = PLANNED_PULL[l] * float(rng.normal(1, .012))
    ORDERS[mo] = dict(mo=mo, l=l, pl=pl, p=p, d=d, pull=pull, batches=set(), cid=campaign_id(l, d, p))
    for sh in range(3):
        push(ts + dt.timedelta(hours=8 * (sh + 1)), "SHIFT", dict(mo=mo, sh=sh + 1))
    push(ts + dt.timedelta(hours=24, seconds=30), "CLOSE_FLOAT", dict(mo=mo))


def on_shift(ts, p):
    o = ORDERS[p["mo"]]
    user = f"BATCHHOUSE-{o['l']}"
    for m, q in RECIPE[o["p"]].items():
        qty = q * o["pull"] / 3 * float(rng.normal(1, .008))
        o["batches"].update(issue_fifo(ts, o["pl"], m, qty, o["mo"], user))


def on_close_float(ts, p):
    o = ORDERS[p["mo"]]
    pen, trans = transition_penalty(o["l"], o["d"], o["p"])
    dev = any(BATCH_INFO.get(b, {}).get("dev") == "FE2O3" for b in o["batches"])
    dt_h, dt_r = FLOAT_DOWNTIME.get((o["l"], o["d"]), (0.0, None))
    y = PROD[o["p"]]["std_yield"] - pen - (float(rng.uniform(.04, .06)) if dev else 0) + float(rng.normal(0, .012))
    y = max(.5, min(.93, y)) * (1 - dt_h / 24)
    good = o["pull"] * y
    cullet = round(o["pull"] - good, 3)
    b = nid("batch", "B26{:07d}")
    BATCH_INFO[b] = dict(supplier=None, gr_id=None, dev=None)
    STOCK[(o["pl"], "RM-CULL")]["UNR"].append([b, cullet, None])
    txn(ts, o["pl"], "RM-CULL", b, "UNRESTRICTED", "531", "By-product receipt: internal cullet return from float line",
        cullet, "PRODUCTION_ORDER", o["mo"], o["mo"], f"BATCHHOUSE-{o['l']}")
    planned_good = PLANNED_PULL[o["l"]] * PROD[o["p"]]["std_yield"]
    T["production_orders"].append(dict(
        production_order_id=o["mo"], plant_id=o["pl"], line_id=o["l"], line_type="FLOAT", product_id=o["p"],
        bom_id=f"BOM-{o['p']}-V1", campaign_id=o["cid"], production_date=o["d"],
        start_ts=at(o["d"], 6), end_ts=at(o["d"], 30), planned_pull_t=r3(PLANNED_PULL[o["l"]]),
        actual_pull_t=r3(o["pull"]), substrate_product_id=None, substrate_issued_t=None,
        planned_good_qty_t=r3(planned_good), good_output_t=r3(good),
        good_output_m2=round(good * 1000 / PROD[o["p"]]["kgm2"], 1), cullet_returned_t=r3(cullet), scrap_t=0.0,
        downtime_hours=dt_h, downtime_reason=dt_r, product_transition_flag=trans, order_status="CONFIRMED"))


def start_finish(ts, l):
    d = ts.date()
    p = FINISH_LINE_PRODUCT[l]
    pl = LINE[l]["plant_id"]
    mo = nid("mo", "MO-{:07d}")
    dt_h = coater_downtime(l, d)
    hrs = 16 if l.startswith("LAM") else 24
    good = LINE[l]["cap"] * float(rng.uniform(.86, .98)) * (1 - dt_h / 24)
    y = PROD[p]["std_yield"] + float(rng.normal(0, .012))
    y = min(y, .99)
    push(ts + dt.timedelta(hours=hrs, seconds=45), "CLOSE_FINISH",
         dict(mo=mo, l=l, pl=pl, p=p, d=d, good=good, y=y, dt_h=dt_h, hrs=hrs))


def on_close_finish(ts, o):
    p = o["p"]
    inp = o["good"] / o["y"]
    sub_p, sub_r = FINISH_BOM[p]["substrate"]
    substrate = o["good"] / o["y"] * (sub_r * PROD[p]["std_yield"])
    for m, q in FINISH_BOM[p].items():
        if m == "substrate":
            continue
        qty = q * o["good"] * PROD[p]["std_yield"] / o["y"] * float(rng.normal(1, .012))
        issue_fifo(ts, o["pl"], m, qty, o["mo"], f"MES-{o['l']}")
    rejects = substrate - o["good"] * (1 if p == "PRD-LOE06" else (1 / 1.02))
    cullet = round(max(0.0, rejects), 3) if p == "PRD-LOE06" else 0.0
    scrap = max(0.0, rejects) if p == "PRD-LAM838" else 0.0
    if cullet > 0:
        b = nid("batch", "B26{:07d}")
        BATCH_INFO[b] = dict(supplier=None, gr_id=None, dev=None)
        STOCK[(o["pl"], "RM-CULL")]["UNR"].append([b, cullet, None])
        txn(ts, o["pl"], "RM-CULL", b, "UNRESTRICTED", "531", "By-product receipt: coater reject glass returned as cullet",
            cullet, "PRODUCTION_ORDER", o["mo"], o["mo"], f"MES-{o['l']}")
    planned = LINE[o["l"]]["cap"] * .92 * (1 - o["dt_h"] / 24)
    T["production_orders"].append(dict(
        production_order_id=o["mo"], plant_id=o["pl"], line_id=o["l"], line_type=LINE[o["l"]]["line_type"],
        product_id=p, bom_id=f"BOM-{p}-V1", campaign_id=None, production_date=o["d"], start_ts=at(o["d"], 6),
        end_ts=at(o["d"], 6 + o["hrs"]), planned_pull_t=None, actual_pull_t=None, substrate_product_id=sub_p,
        substrate_issued_t=r3(substrate), planned_good_qty_t=r3(planned), good_output_t=r3(o["good"]),
        good_output_m2=round(o["good"] * 1000 / PROD[p]["kgm2"], 1), cullet_returned_t=r3(cullet), scrap_t=r3(scrap),
        downtime_hours=o["dt_h"], downtime_reason="PLANNED_TARGET_CHANGE" if o["dt_h"] else None,
        product_transition_flag=False, order_status="CONFIRMED"))


# =====================================================================================
# MRP + month-end + scrap events
# =====================================================================================
def on_mrp(ts, _):
    d = ts.date()
    for k in PM:
        pl, m = k
        if AVG_USE[k] == 0:
            continue
        onhand_unr = unr_total(pl, m)
        ip = onhand_unr + qi_total(pl, m) + OPEN_SCHED[k]
        lt = int(math.ceil(plan_lt(k)))
        cover = POLICY[m][2]
        trigger = usage(pl, m, d + dt.timedelta(1), lt + 2) + SS[k]
        if ip < trigger:
            q = usage(pl, m, d + dt.timedelta(1), lt + cover) + SS[k] - ip
            q = math.ceil(q / POLICY[m][0]) * POLICY[m][0]
            if q > 0:
                create_order(d, k, q)
        # Expedite when unrestricted stock falls below half of safety stock
        if onhand_unr < .5 * SS[k] and (d - LAST_EXPEDITE.get(k, dt.date(2000, 1, 1))).days > 5 and len(QUOTA[k]) > 1:
            late_sup = "SUP007" if m == "RM-SODA" else None
            q = math.ceil(SS[k] / POLICY[m][0]) * POLICY[m][0]
            create_order(d, k, q, expedite=True, exclude=late_sup)
            LAST_EXPEDITE[k] = d


def on_month_end(ts, _):
    for k in PM:
        pl, m = k
        if MAT[m]["storage"] not in BULK or not STOCK[k]["UNR"]:
            continue
        month_use = usage(pl, m, ts.date().replace(day=1), ts.day)
        delta = round(month_use * float(rng.normal(-.0015, .003)), 3)
        q = STOCK[k]["UNR"]
        if delta >= 0:
            q[-1][1] += delta
            b = q[-1][0]
            txn(ts, pl, m, b, "UNRESTRICTED", "701", "Physical inventory gain (silo level survey)", delta,
                "PHYSICAL_INVENTORY", f"PI-{pl}-{ts:%Y%m}", None, EMP_BY[(pl, "PLANNER")][0])
        else:
            need = -delta
            while need > 5e-4 and q:
                take = round(min(q[0][1], need), 3)
                txn(ts, pl, m, q[0][0], "UNRESTRICTED", "702", "Physical inventory loss (silo level survey)", -take,
                    "PHYSICAL_INVENTORY", f"PI-{pl}-{ts:%Y%m}", None, EMP_BY[(pl, "PLANNER")][0])
                q[0][1] -= take
                need -= take
                if q[0][1] <= 5e-4:
                    q.popleft()


SCRAP_EVENTS = []
for pl in ("PL01", "PL03"):
    for mth in (7, 8, 9):
        SCRAP_EVENTS.append((at(dt.date(2026, mth, int(rng.integers(3, 27))), rng.uniform(8, 16)), pl, "RM-PVB",
                             802.5 * int(rng.integers(1, 3)), "Roll edge damage during forklift handling"))
SCRAP_EVENTS.append((at(dt.date(2026, 8, 14), 10.5), "PL01", "RM-FEOX", 50.0, "Bags torn and contaminated in warehouse"))
SCRAP_EVENTS.append((at(dt.date(2026, 9, 3), 14.2), "PL02", "RM-CARB", 1.2, "Spillage at carbon bin transfer"))


def on_scrap(ts, p):
    pl, m, qty, reason = p
    q = STOCK[(pl, m)]["UNR"]
    need = qty
    while need > 5e-4 and q:
        take = round(min(q[0][1], need), 3)
        txn(ts, pl, m, q[0][0], "UNRESTRICTED", "551", "Scrap / write-off from unrestricted stock", -take,
            "SCRAP_DOC", f"SCR-{pl}-{ts:%y%m%d}", None, EMP_BY[(pl, "PLANNER")][0], reason)
        q[0][1] -= take
        need -= take
        if q[0][1] <= 5e-4:
            q.popleft()


# ---- schedule recurring events ----
for d in SIM_DAYS:
    for l in FLOAT_PLAN:
        push(at(d, 6), "START_FLOAT", l)
    for l in FINISH_LINE_PRODUCT:
        if finishing_works(l, d):
            push(at(d, 6, ), "START_FINISH", l)
    push(at(d, 7), "MRP", None)
for me in (dt.date(2026, 7, 31), dt.date(2026, 8, 31), dt.date(2026, 9, 30)):
    push(at(me, 23.5), "MONTH_END", None)
for e in SCRAP_EVENTS:
    push(e[0], "SCRAP", e[1:])

# PO creation date lookup is needed by on_arrival; wrap create_order
_co = create_order


def create_order(d, k, qty, expedite=False, exclude=None):
    n_before = len(T["purchase_orders"])
    _co(d, k, qty, expedite, exclude)
    for po in T["purchase_orders"][n_before:]:
        T_PO_DATE[po["po_id"]] = po["created_ts"].date()


# =====================================================================================
# RUN
# =====================================================================================
HANDLERS = {"START_FLOAT": lambda ts, p: start_float(ts, p), "SHIFT": on_shift, "CLOSE_FLOAT": on_close_float,
            "START_FINISH": lambda ts, p: start_finish(ts, p), "CLOSE_FINISH": on_close_finish,
            "MRP": on_mrp, "ARRIVAL": on_arrival, "UD": on_ud, "RTV": on_rtv, "MONTH_END": on_month_end,
            "SCRAP": on_scrap}
while evq:
    ts, _, kind, payload = heapq.heappop(evq)
    if ts > END_TS:
        continue
    HANDLERS[kind](ts, payload)

# Production orders still running at cut-off (float day 30-Sep 06:00 -> 1-Oct 06:00) are IN_PROCESS
_done = {r["production_order_id"] for r in T["production_orders"]}
for mo, o in ORDERS.items():
    if mo not in _done:
        T["production_orders"].append(dict(
            production_order_id=mo, plant_id=o["pl"], line_id=o["l"], line_type="FLOAT", product_id=o["p"],
            bom_id=f"BOM-{o['p']}-V1", campaign_id=o["cid"], production_date=o["d"], start_ts=at(o["d"], 6),
            end_ts=None, planned_pull_t=r3(PLANNED_PULL[o["l"]]), actual_pull_t=None, substrate_product_id=None,
            substrate_issued_t=None, planned_good_qty_t=r3(PLANNED_PULL[o["l"]] * PROD[o["p"]]["std_yield"]),
            good_output_t=None, good_output_m2=None, cullet_returned_t=None, scrap_t=None,
            downtime_hours=None, downtime_reason=None, product_transition_flag=None, order_status="IN_PROCESS"))

# =====================================================================================
# DIMENSIONS & REFERENCE TABLES
# =====================================================================================
T["dim_date"] = [dict(date_key=int(d.strftime("%Y%m%d")), date=d, day_of_week=d.strftime("%A"),
                      day_of_week_no=d.isoweekday(), week_of_year=d.isocalendar()[1], month_no=d.month,
                      month_name=d.strftime("%B"), quarter=f"Q{(d.month - 1) // 3 + 1}", year=d.year,
                      year_month=d.strftime("%Y-%m"), is_weekend=d.weekday() >= 5,
                      is_us_holiday=d in HOLIDAYS, holiday_name=HOLIDAYS.get(d),
                      fiscal_year=f"FY{d.year}", fiscal_period=d.month)
                 for d in drange(dt.date(2026, 6, 1), dt.date(2026, 12, 31))]
T["dim_plant"] = PLANTS
T["dim_production_line"] = [dict(line_id=v["line_id"], plant_id=v["plant_id"], line_type=v["line_type"],
                                 line_name=v["line_name"], nameplate_capacity_tpd=v["cap"], capacity_basis=v["basis"],
                                 operating_pattern="24x7" if v["line_type"] != "LAMINATION" else
                                 ("2 shifts Mon-Sat" if v["line_id"] == "LAM-PL01-1" else "2 shifts Mon-Fri"))
                            for v in LINE.values()]
T["dim_product"] = [dict(product_id=v["product_id"], product_name=v["name"], product_family=v["family"],
                         glass_type=v["glass_type"], nominal_thickness_mm=v["thk"], production_route=v["route"],
                         weight_kg_per_m2=v["kgm2"], standard_yield_pct=round(v["std_yield"] * 100, 1),
                         production_uom="t", sales_uom="m2") for v in PROD.values()]
T["dim_material"] = [dict(material_id=v["material_id"], material_name=v["name"], material_group=v["group"],
                          base_uom=v["uom"], storage_type=v["storage"], standard_price_usd=v["price"],
                          shelf_life_days=v["shelf"], hazardous_flag=v["haz"],
                          critical_to_quality=v["material_id"] in ("RM-SAND-STD", "RM-SAND-LI", "RM-SODA", "RM-CULL", "RM-PVB", "RM-TGT-AG"))
                     for v in MAT.values()]
T["dim_supplier"] = [dict(supplier_id=v["supplier_id"], supplier_name=v["name"], city=v["city"],
                          state_region=v["state"], country=v["country"], supplier_type=v["stype"],
                          supplier_tier=v["tier"], payment_terms=v["terms"], default_currency=v["ccy"],
                          supplier_since_year=v["since"], esg_rating=v["esg"], account_status="ACTIVE")
                     for v in SUP.values()]
T["dim_carrier"] = [dict(carrier_id=c[0], carrier_name=c[1], carrier_mode=c[2], country=c[3]) for c in CARRIERS]
T["dim_employee"] = [dict(employee_id=e[0], employee_name=e[1], job_title=e[2], plant_id=None if e[3] == "HQ" else e[3],
                          location="Corporate HQ" if e[3] == "HQ" else e[3], functional_role=e[4]) for e in EMPLOYEES]

for p, rec in RECIPE.items():
    for m, q in rec.items():
        T["bom"].append(dict(bom_id=f"BOM-{p}-V1", bom_version=1, product_id=p, component_type="MATERIAL",
                             component_id=m, component_role=ROLE[MAT[m]["group"]],
                             component_qty=round(q / PROD[p]["std_yield"], 6), component_uom=MAT[m]["uom"],
                             base_qty=1, base_uom="t good output", melt_ratio_per_t_pull=q,
                             valid_from=dt.date(2026, 1, 1), valid_to=dt.date(9999, 12, 31)))
for p, rec in FINISH_BOM.items():
    for m, q in rec.items():
        if m == "substrate":
            T["bom"].append(dict(bom_id=f"BOM-{p}-V1", bom_version=1, product_id=p, component_type="PRODUCT",
                                 component_id=q[0], component_role="SUBSTRATE", component_qty=q[1],
                                 component_uom="t", base_qty=1, base_uom="t good output", melt_ratio_per_t_pull=None,
                                 valid_from=dt.date(2026, 1, 1), valid_to=dt.date(9999, 12, 31)))
        else:
            T["bom"].append(dict(bom_id=f"BOM-{p}-V1", bom_version=1, product_id=p, component_type="MATERIAL",
                                 component_id=m, component_role=ROLE[MAT[m]["group"]], component_qty=q,
                                 component_uom=MAT[m]["uom"], base_qty=1, base_uom="t good output",
                                 melt_ratio_per_t_pull=None, valid_from=dt.date(2026, 1, 1), valid_to=dt.date(9999, 12, 31)))

for m, specs in SPECS.items():
    for sp in specs:
        T["material_specifications"].append(dict(
            spec_id=f"SPEC-{m}-{sp['code']}", material_id=m, characteristic_code=sp["code"],
            characteristic_name=sp["name"], uom=sp["uom"], lower_spec_limit=sp["lsl"], upper_spec_limit=sp["usl"],
            target_value=sp["tgt"], deviation_lower_limit=sp["dlsl"], deviation_upper_limit=sp["dusl"],
            deviation_allowed=sp["allow"], test_method=sp["method"],
            critical_characteristic=not sp["allow"]))

for k in PM:
    pl, m = k
    if AVG_USE[k] == 0:
        continue
    T["material_plant_parameters"].append(dict(
        plant_id=pl, material_id=m, storage_location_id=SLOC[k], storage_type=MAT[m]["storage"],
        mrp_type="REORDER_POINT_FORECAST", mrp_controller_id=EMP_BY[(pl, "PLANNER")][0],
        safety_stock_days=POLICY[m][3], safety_stock_qty=r3(SS[k]), planning_lead_time_days=round(plan_lt(k), 1),
        order_cover_days=POLICY[m][2], rounding_lot_qty=POLICY[m][0], uom=MAT[m]["uom"],
        avg_daily_planned_usage=r3(AVG_USE[k]),
        storage_capacity_qty=r3(max(SS[k] * 4, AVG_USE[k] * 30) if MAT[m]["storage"] in BULK else AVG_USE[k] * 120),
        procurement_type="EXTERNAL_AND_INTERNAL_RETURN" if m == "RM-CULL" else "EXTERNAL"))

CERT_ROWS = []
cert_n = itertools.count(1)
for s, v in SUP.items():
    certs = [("ISO 9001:2015", "Quality management")]
    if v["esg"] in ("A", "B"):
        certs.append(("ISO 14001:2015", "Environmental management"))
    if v["tier"] == "STRATEGIC":
        certs.append(("ISO 45001:2018", "Occupational health & safety"))
    if s in ("SUP015", "SUP016"):
        certs.append(("RMI Conflict Minerals Reporting Template", "Responsible minerals declaration"))
    if s == "SUP018":
        certs.append(("EU REACH Registration", "Chemical regulatory compliance"))
    for ctype, desc in certs:
        issue = dt.date(2023 + int(rng.integers(0, 3)), int(rng.integers(1, 13)), 1)
        expiry = issue.replace(year=issue.year + 3) - dt.timedelta(1)
        status = "VALID"
        if s == "SUP003" and ctype.startswith("ISO 9001"):
            issue, expiry, status = dt.date(2023, 9, 1), dt.date(2026, 8, 31), "EXPIRED"
        if s == "SUP015" and ctype.startswith("RMI"):
            issue, expiry = dt.date(2025, 10, 15), dt.date(2026, 10, 14)
        if expiry < dt.date(2026, 9, 30) and status == "VALID":
            issue, expiry = expiry + dt.timedelta(1), expiry.replace(year=expiry.year + 3)
        T["supplier_certifications"].append(dict(
            certification_id=f"CERT-{next(cert_n):04d}", supplier_id=s, certification_type=ctype,
            certification_scope=desc, certifying_body=str(rng.choice(["Bureau Veritas", "DNV", "SGS", "TUV SUD", "Intertek", "LRQA"]))
            if not ctype.startswith(("RMI", "EU REACH")) else "Self-declaration",
            issue_date=issue, expiry_date=expiry, status=status,
            renewal_audit_date=dt.date(2026, 10, 20) if status == "EXPIRED" else None))

# Demand forecast (consensus S&OP, monthly, plant x product, external demand in good tonnes)
fcst_n = itertools.count(1)
for mth in (7, 8, 9):
    md = [d for d in SIM_DAYS if d.month == mth]
    planned = defaultdict(float)
    for l, sched in FLOAT_PLAN.items():
        for d in md:
            planned[(LINE[l]["plant_id"], sched[d])] += PLANNED_PULL[l] * PROD[sched[d]]["std_yield"]
    for l, p in FINISH_LINE_PRODUCT.items():
        pl = LINE[l]["plant_id"]
        fin = sum(LINE[l]["cap"] * .92 * (1 - coater_downtime(l, d) / 24) for d in md if finishing_works(l, d))
        planned[(pl, p)] += fin
        sub_p, r = FINISH_BOM[p]["substrate"]
        planned[(pl, sub_p)] -= fin * r
    for (pl, p), q in sorted(planned.items()):
        q *= float(rng.normal(1, .04))
        created = dt.date(2026, mth - 1, 15)
        T["demand_forecast"].append(dict(
            forecast_id=f"FC-{next(fcst_n):05d}", forecast_version=f"SOP-2026-{mth - 1:02d}",
            forecast_type="CONSENSUS_SOP", plant_id=pl, product_id=p, period_month=dt.date(2026, mth, 1),
            forecast_qty_t=r3(q), forecast_qty_m2=round(q * 1000 / PROD[p]["kgm2"], 0),
            created_ts=at(created, 16), created_by=EMP_BY[(pl, "PLANNER")][0]))

# =====================================================================================
# WRITE
# =====================================================================================
ORDER = ["dim_date", "dim_plant", "dim_production_line", "dim_product", "dim_material", "dim_supplier",
         "dim_carrier", "dim_employee", "bom", "material_specifications", "material_plant_parameters",
         "supplier_material_contracts", "supplier_certifications", "demand_forecast",
         "purchase_requisitions", "purchase_orders", "purchase_order_lines", "po_schedule_lines",
         "inbound_shipments", "goods_receipts", "quality_inspection_lots", "quality_inspection_results",
         "nonconformance_reports", "supplier_invoices", "inventory_transactions", "production_orders"]
SORT = {"inventory_transactions": ["txn_ts", "txn_id"], "production_orders": ["production_order_id"],
        "inbound_shipments": ["shipment_id"], "purchase_orders": ["po_id"], "supplier_invoices": ["invoice_id"]}
counts = {}
for name in ORDER:
    df = pd.DataFrame(T[name])
    if name in SORT:
        df = df.sort_values(SORT[name]).reset_index(drop=True)
    if name == "inventory_transactions":
        df["txn_id"] = [f"IT-{i + 1:07d}" for i in range(len(df))]
    for c in df.columns:
        sample = df[c].dropna().iloc[0] if df[c].notna().any() else None
        if pd.api.types.is_datetime64_any_dtype(df[c]) or isinstance(sample, dt.datetime):
            df[c] = pd.to_datetime(df[c]).dt.strftime("%Y-%m-%d %H:%M:%S")
    df.to_csv(os.path.join(OUT, f"silver_{name}.csv"), index=False)
    counts[name] = len(df)
print(pd.Series(counts).to_string())
print("shortages:", len(SHORTAGES))
for s in SHORTAGES[:20]:
    print(s)
